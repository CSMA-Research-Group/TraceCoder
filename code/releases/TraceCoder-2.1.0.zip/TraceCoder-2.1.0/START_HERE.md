# TraceCoder 2.1.0

在解压目录打开终端，执行：

```bash
sh code/scripts/start.sh --port 8767
```

打开 http://127.0.0.1:8767 。需 macOS / Linux + Python 3.9 或以上；Windows 可用 WSL2 或 Docker。

首次启动自动安装锁定的 Python 依赖，需要访问包源；安装后固定演示无需联网与模型密钥。代码与测试每次实际执行。

- 完整说明：[code/README.md](code/README.md)
- 部署与接入：[code/docs/DEPLOYMENT.md](code/docs/DEPLOYMENT.md)
- 论文对应：[code/docs/PAPER_MAPPING.md](code/docs/PAPER_MAPPING.md)
- 验收边界：[code/docs/SYSTEM_ACCEPTANCE.md](code/docs/SYSTEM_ACCEPTANCE.md)

解压后可运行 `python3 code/scripts/verify_release.py .` 校验全部文件哈希。
运行数据由首次启动创建，本包不含用户项目、历史运行或密钥。
